tNode* llCreate();
void llDisplay(tNode*);
void llAdd(tNode**, int, int);
int size(tNode*);
void addAtIndex(tNode**, int, int, int);
void removeAtIndex(tNode**, int);
void removeInt(tNode**, int);
void llDelete(tNode**);
void addInOrder(tNode**, int, int);
